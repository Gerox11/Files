let predkosc_rur=5
let maksymalna_predkosc_rur=20
let licznik=0
let koniec=true
let ptak 
let przeszkody=[]
let canvas=document.getElementById("canvas")
let ctx=canvas.getContext("2d")
let interval
class Ptaszek{
    constructor(x,y,r,kp,kk)
    {
        this.x=x
        this.y=y
        this.r=r
        this.kp=kp
        this.kk=kk
        this.vy=0
    }
    rysuj()
    {
        ctx.beginPath()
        ctx.fillStyle = "red"
        ctx.strokeStyle="black"
        ctx.arc(this.x,this.y,this.r,this.kp,this.kk)
        ctx.fill()
        ctx.closePath()
        ctx.beginPath()
        ctx.fillStyle="black"
        ctx.arc(this.x+20,this.y-10,this.r*0.15,this.kp,this.kk)
        ctx.fill()
        ctx.closePath()
        ctx.beginPath()
        ctx.fillStyle="white"
        ctx.arc(this.x+2,this.y+5.5,this.r*0.9,this.kp,this.kk*0.3)
        ctx.fill()
        ctx.closePath()
        ctx.beginPath()
        ctx.fillStyle="orange"
        ctx.moveTo(this.x+30,this.y-5)
        ctx.lineTo(this.x+50,this.y-3)
        ctx.lineTo(this.x+30,this.y+5)
        ctx.fill()
    }
    skok(event)
    {
        let znak=event.key
        let sila=8
        if(event.repeat)
        {
            return
        }
        if(znak == " ")
        {
            this.vy=-sila
        }
    }
    spadanie()
    {
        let grawitacja=0.4
        let maksymalna=8
        this.vy+=grawitacja
        if(this.vy>maksymalna)
        {
            this.vy=maksymalna
        }
        this.y+=this.vy
    }
    koniec_gry()
    {
        if(this.y + this.r >=600 || this.y - this.r <= 0)
        {
            koniec = true
        }
    }
}
class Przeszkoda
{
    constructor(x)
    {
        this.x=x
        this.szerokosc=75
        this.wysokosc=Math.random()*200+50
        this.odstep=250
    }
    rysuj_przeszkode()
    {
       ctx.fillStyle="green"
       ctx.fillRect(this.x,0,this.szerokosc,this.wysokosc)
       ctx.fillRect(this.x,this.wysokosc + this.odstep,this.szerokosc,canvas.height)
    }
    ruszanie()
    {
        this.x -= predkosc_rur
    }
    hitboxy(ptak)
    {
        if(ptak.x+ptak.r>this.x&&ptak.x-ptak.r<this.x+this.szerokosc&&ptak.y-ptak.r<this.wysokosc)
        {
            koniec=true
        }
        if(ptak.x+ptak.r>this.x&&ptak.x-ptak.r<this.x+this.szerokosc&&ptak.y+ptak.r>this.wysokosc+this.odstep)
        {
            koniec=true
        }
    }
}
    function skok(event)
    {
        ptak.skok(event)
    }
    function petla()
    {
        if(koniec)
        {
            clearInterval(interval)
            ctx.font="50px Verdana"
            ctx.fillStyle="black"
            ctx.fillText(`Przegrałeś! Zdobyłeś ${licznik} punkt/ów `,120,150)
            return
        } 
        ptak.koniec_gry()
        ctx.clearRect(0,0,1200,600)
        for(let i=0;i<przeszkody.length;i++)
            {
                przeszkody[i].rysuj_przeszkode()
                przeszkody[i].ruszanie()
                przeszkody[i].hitboxy(ptak)
            }
            if(przeszkody[przeszkody.length - 1].x < 600)
            {
                przeszkody.push(new Przeszkoda(1200))
            }
        if(przeszkody[0].x<-100)
        {
            przeszkody.splice(0,1)
            licznik++
            if(licznik%5==0)
            {
                if(predkosc_rur<maksymalna_predkosc_rur)
                {
                    predkosc_rur+=0.5
                }
            }
        }
            ptak.rysuj()
            ptak.spadanie()
            if(licznik<10)
            {
              ctx.fillStyle = "rgba(0,0,0,0.6)"
              ctx.fillRect(1120, 5, 65, 55)
              ctx.font="50px Arial"
              ctx.fillStyle = "white"
              ctx.fillText(licznik,1140,50)
            }
            else
            {
              ctx.fillStyle = "rgba(0,0,0,0.6)"
              ctx.fillRect(1120, 5, 75, 55)
              ctx.font="50px Arial"
              ctx.fillStyle = "white"
              ctx.fillText(licznik,1130,50)
            }
    }
        function startgame()
        {
            document.getElementById("guzik").blur()
            koniec=false
            ptak=new Ptaszek(50,60,30,0,2*Math.PI)
            przeszkody=[new Przeszkoda(1200)]
            interval = setInterval(petla, 15)
        }